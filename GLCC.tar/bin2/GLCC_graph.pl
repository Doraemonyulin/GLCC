#!usr/bin/perl -w
use strict;
use Graph::Undirected;
my $g=Graph::Undirected->new;
open IN,"../gene_meta_eliminate.some.contigandgene.blastout2";
open OUT,">","../graph/graph.txt";

my @gene;
my $j=0;
while(<IN>)
{
	chomp;
	next unless $_;
	my @line=split(/\s+/,$_);
	$g->add_edge($line[0],$line[1]);	
}
close IN;
for($j=0;$j<=363671;$j++)
{
my @v=$g->connected_component_by_index($j);
next if($#v<=1);
print OUT "@v\n";
}
close OUT;
