#!usr/bin/perl -w
use strict;

open IN,"../graph/graph.txt";
open OUT1,">","../graph/GLCC_contig.txt";
open OUT2,">","../graph/GLCC_gene.txt";

while(<IN>)
{
	chomp;
	next unless $_;
	my @line=split(/\s+/,$_);
	for(my $i=0;$i<=$#line;$i++)
	{
		my $tem=$line[$i];
		my @cg=split(/\./,$tem);
		if($#cg==3)
			{print OUT1 "$tem\t";}
		if($#cg==5)
			{print OUT2 "$tem\t";}
	}
	print OUT1 "\n";
	print OUT2 "\n";
}
close IN;
close OUT1;
close OUT2;

open IN1,"../graph/GLCC_contig.txt";
open IN2,"../graph/GLCC_gene.txt";
open OUT3,">","../graph/stat_GLCC_contig.txt";
open OUT4,">","../graph/stat_GLCC_gene.txt";
my $j=0;
while(<IN1>)
{
	chomp;
	next unless $_;
	my $total=$_;
	my @line=split(/\t+/,$_);
	my $num=$#line+1;
	print OUT3 "$j\t$num\t$total\n";
	$j++;
}
close IN1;
close OUT3;

my $k=0;
while(<IN2>)
{
        chomp;
        next unless $_;
        my $total=$_;
        my @line=split(/\t+/,$_);
        my $num=$#line+1;
        print OUT4 "$k\t$num\t$total\n";
	$k++;
}
close IN2;
close OUT4;

