#!usr/bin/perl -w
use strict;

#this program is used to eliminate some blast results,eliminate some contigs and genes

open IN1,"/home/kangyulin/wanxiong12/gene_meta.blast.improved.out";
open IN2,"../genenum_species_GLCCnewid_oldid_contignum_contigs.txt";
open IN3,"../gene_genus_nonuniq.txt";
open IN4,"/home/kangyulin/core_gene_blast/final_core_genecatlog_identity30_length30.blast.out";
open OUT,">","../gene_meta_eliminate.some.contigandgene.blastout2"; 

my %gene;
my %contig;


while(<IN2>)
{
	chomp;
	next unless $_;
	my @line=split(/\s+/,$_);
	for(my $j=5;$j<=$#line;$j++)
		{
			$contig{$line[$j]}++;
			
		}
}
close IN2;


while(<IN3>)
{
	chomp;
	next unless $_;
	$gene{$_}++;
}
close IN3;

while(<IN4>)
{
	chomp;
	next unless $_;
	my @line=split(/\t+/,$_);
	$gene{$line[1]}++;
}
close IN4;

while(<IN1>)
{
	chomp;
	next unless $_;
	my $tem = $_;
	my @line = split(/\t+/,$_);
	next if exists $gene{$line[0]};
	#next unless exists $contig{$line[1]};
	print OUT "$tem\n";
}
close IN1;
close OUT;
